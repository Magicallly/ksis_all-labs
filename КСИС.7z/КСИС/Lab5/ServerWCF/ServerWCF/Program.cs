﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Server working only with Admin 
namespace ServerWCF
{
    [ServiceContract]
    public interface IService
    {
        [OperationContract]
        [WebGet]
        string EchoWithGet(string s);

        [OperationContract]
        [WebInvoke]
        string EchoWithPost(string s);

        [OperationContract]
        [WebGet]
        int ReturnWordsNumber();

        [OperationContract]
        [WebGet]
        string ReturnWords();
    }

    public class Service : IService
    {
        //Количество слов в глобальном массиве - 

        //Все Принятые слова - вернуть

        //

        public string EchoWithGet(string s)
        {
            Program.GlobalList.Add(s);
            int count = s.Split(new char[] { ' ', '\n'},StringSplitOptions.RemoveEmptyEntries).Length;
            Program.WordsCount += count;
            return String.Format("You said: {0} Number of words: {1}", s, count);
        }

        public string EchoWithPost(string s)
        {
            return "You said " + s;
        }

        public int ReturnWordsNumber()
        {
            return Program.WordsCount;
        }

        public string ReturnWords()
        {
            return String.Join("\n",Program.GlobalList.ToArray());
        }

    }

    public class Program
    {
        public static List<string> GlobalList = new List<string>();
        public static int WordsCount;

        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(Service), new Uri("http://localhost:8000"));
            host.AddServiceEndpoint(typeof(IService), new BasicHttpBinding(), "Soap");
            ServiceEndpoint endpoint = host.AddServiceEndpoint(typeof(IService), new WebHttpBinding(), "Web");
            endpoint.Behaviors.Add(new WebHttpBehavior());
            
            try
            {
                host.Open();
                

                Console.WriteLine("Press [Enter] to terminate");
                Console.ReadLine();
                host.Close();
            }
            catch (CommunicationException cex)
            {
                Console.WriteLine("An exception occurred: {0}", cex.Message);
                Console.ReadLine();
                host.Abort();
            }
        }
    }
}
