﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.Threading.Tasks;


namespace Client
{
    [ServiceContract]
    public interface IService
    {
        [OperationContract]
        [WebGet]
        string EchoWithGet(string s);

        [OperationContract]
        [WebInvoke]
        string EchoWithPost(string s);

        [OperationContract]
        [WebGet]
        int ReturnWordsNumber();

        [OperationContract]
        [WebGet]
        string ReturnWords();
    }

    class Program
    {
        static void Main(string[] args)
        {
            using (ChannelFactory<IService> scf = new ChannelFactory<IService>(new BasicHttpBinding(), "http://localhost:8000/Soap"))
            {
                IService channel = scf.CreateChannel();

                string str;
                int num;
                int choice;
                Console.WriteLine("-----------Menu----------------");
                Console.WriteLine("0)Send string -----------------");
                Console.WriteLine("1)Send strinds (until <CRLF>)--");
                Console.WriteLine("2)Get All strings -------------");
                Console.WriteLine("3)Get number of strings -------");

                do
                {
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 0:
                            {
                                channel.EchoWithGet(Console.ReadLine());
                                Console.WriteLine("-OK-");
                                break;
                            }
                        case 1:
                            {
                                str = "";
                                var temp = new List<string>();
                                do
                                {
                                    if (str != "")
                                        temp.Add(str);
                                    str = Console.ReadLine();
                                    
                                }
                                while (str != "<CRLF>");
                                channel.EchoWithGet(String.Join("\n", temp));
                                Console.WriteLine("-OK-");
                                break;
                            }
                        case 2:
                            {
                                Console.WriteLine(channel.ReturnWords());
                                Console.WriteLine("-OK-");
                                break;
                            }
                        case 3:
                            {
                                Console.WriteLine(channel.ReturnWordsNumber());
                                Console.WriteLine("-OK-");
                                break;
                            }
                        case 4:
                            {
                                Console.WriteLine("Exit");
                                break;
                            }
                    }
                }
                while (choice != 4) ;


                Console.ReadKey(true);
            }
        }
    }
}
