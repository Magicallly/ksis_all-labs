﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ParserInterfaces;

namespace UDPClient
{
    class UDPClient
    {
        static private List<DateTime> ticks = new List<DateTime>();

        static private void GetTime(IWCFParserService proxy)
        {
            while (true)
            {
                ticks.Add(proxy.SendTime());
                Console.WriteLine(ticks[ticks.Count - 1]);
                Thread.Sleep(new TimeSpan(0, 0, 1));
            }
        }

        static void Main(string[] args)
        {
            string serviceAddress = "soap.udp://224.0.0.1:40000";
            UdpBinding myBinding = new UdpBinding();
            ChannelFactory<IWCFParserService> factory = new ChannelFactory<IWCFParserService>(myBinding,
                            new EndpointAddress(serviceAddress));
            IWCFParserService proxy = factory.CreateChannel();
            Thread timer = new Thread(() => GetTime(proxy));
            timer.Start();
            Console.ReadKey();
            timer.Abort();
            
            return;
           
        }
    }
}
