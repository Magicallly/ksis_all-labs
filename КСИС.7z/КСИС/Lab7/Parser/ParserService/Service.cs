﻿using ParserInterfaces;
using System;
using System.ServiceModel;

namespace ParserService
{
    class Service
    {
        static void Main(string[] args)
        {
      
            using (ServiceHost host = new ServiceHost(typeof(WCFParserService)))
            {
                host.AddServiceEndpoint(typeof(IWCFParserService), new NetTcpBinding(),"net.tcp://localhost:8000/tcp");
                host.Open();
                Console.WriteLine("Server one is open...");
                Console.WriteLine("Press enter to close server");
                Console.ReadLine();
            }
        }
    }
}
