﻿using ParserInterfaces;
using System;
using System.Collections.Generic;
using System.IO;

namespace ParserService
{
    public class WCFParserService : IWCFParserService
    {
        static private List<string> GlobalList = new List<string>();

        public long ParseStrings(List<string> strings)
        {
            GlobalList.AddRange(strings);
            long count = 0;
            foreach (var str in strings)
            {
                count += str.Split(' ').LongLength;
            }
            return count;
        }

        public long ParseText(string text)
        {
            return text.Split(' ').LongLength;
        }

        public List<string> RetrieveList()
        {
            return GlobalList;
        }

        public void Echo(string name)
        {
            Console.WriteLine("Echo from " + name);
        }

        public string Base64Encode(byte[] data)
        {
            return Convert.ToBase64String(data);
        }

        public byte[] Base64Decode(string base64EncodedData)
        {
            return Convert.FromBase64String(base64EncodedData);
        }

        public string Base64EncodeLocal(string filename, int start, int length)
        {
            byte[] data;
            try
            {
                data = File.ReadAllBytes(filename);
            }
            catch(Exception e)
            {
                return e.Message;
            }
            byte[] exp = new byte[length];
            Array.Copy(data, start, exp, 0, length);
            return Convert.ToBase64String(exp);
        }

        public void PutFile(string filename, byte[] data)
        {
            using(BinaryWriter fs = new BinaryWriter(new FileStream(filename, FileMode.OpenOrCreate)))
            {
                fs.Write(data);
            }
        }

        public byte[] GetFile(string filename, int start, int length)
        {
            if (File.Exists(filename))
            {
                byte[] data = File.ReadAllBytes(filename);
                byte[] exp = new byte[length > data.Length ? data.Length : length];
                Array.Copy(data, start, exp, 0, length > data.Length ? data.Length : length);
                return exp;
            }
            return null;
        }

        public DateTime SendTime()
        {
            return DateTime.Now;
        }
    }
}


