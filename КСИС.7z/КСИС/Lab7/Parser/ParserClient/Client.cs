﻿using System;
using System.Collections.Generic;
using System.IO;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Timers;
using ParserInterfaces;

namespace ParserClient
{
    class Client
    {
        static private List<DateTime> ticks = new List<DateTime>();

        static private void GetTime(IWCFParserService proxy)
        {
            while (true)
            {
                ticks.Add(proxy.SendTime());
                Thread.Sleep(new TimeSpan(0, 0, 1));
            }

        }

        static void Main(string[] args)
        {
            var cf = new ChannelFactory<IWCFParserService>(new NetTcpBinding(), "net.tcp://localhost:8000/tcp");
            var proxy = cf.CreateChannel();
            Thread timer = new Thread(() => GetTime(proxy));
            timer.Start();
            while (true)
            {
                Console.WriteLine("--------------------\n   1.Parse Text\n   2.Parse strings\n   3.Retrieve List\n   4.Echo\n   5.Encode B64\n   6.Decode B64\n   7.Encode Local B64\n   8.Get File\n   9.Put File\n--------------------\n");
                string s = Console.ReadLine();
                switch (s)
                {
                    case "1":
                        Console.WriteLine("Enter string: ");
                        string text = Console.ReadLine();
                        Console.WriteLine(proxy.ParseText(text));
                        break;
                    case "2":
                        List<string> parse = new List<string>();
                        string pass = string.Empty;
                        Console.WriteLine("Enter strings: (stop to send)");
                        while (!pass.Equals("stop"))
                        {
                            pass = Console.ReadLine();
                            parse.Add(pass);
                        }
                        parse.Remove("stop");
                        Console.WriteLine(proxy.ParseStrings(parse));
                        break;
                    case "3":
                        List<string> list = new List<string>();
                        list.AddRange(proxy.RetrieveList());
                        Console.WriteLine("Retrieved list: ");
                        foreach (var str in list)
                        {
                            Console.WriteLine(str);
                        }
                        break;
                    case "4":
                        Console.Write("Enter word for echo: ");
                        string echo = Console.ReadLine();
                        proxy.Echo(echo);
                        break;
                    case "5":
                        Console.Write("Enter file name for encoding: ");
                        string fn = Console.ReadLine();
                        Console.WriteLine(proxy.Base64Encode(File.ReadAllBytes(fn)));
                        break;
                    case "6":
                        Console.Write("Enter base64 string to decode: ");
                        string b64 = Console.ReadLine();
                        byte[] res = proxy.Base64Decode(b64);
                        Console.WriteLine(Encoding.ASCII.GetString(res));
                        break;
                    case "7":
                        Console.Write("Enter file name on server to encode: ");
                        fn = Console.ReadLine();
                        Console.WriteLine(proxy.Base64EncodeLocal(fn, 0, 10));
                        break;
                    case "8":
                        Console.Write("Enter file name to get: ");
                        fn = Console.ReadLine();
                        Console.Write("Enter start of block: ");
                        int start = int.Parse(Console.ReadLine());
                        Console.Write("Enter length of block: ");
                        int length = int.Parse(Console.ReadLine());
                        byte[] data = proxy.GetFile(fn, start, length);
                        using (BinaryWriter br = new BinaryWriter(new FileStream(fn, FileMode.OpenOrCreate)))
                        {
                            br.Write(data);
                        }
                        break;
                    case "9":
                        Console.Write("Enter file name to put on server: ");
                        fn = Console.ReadLine();
                        if (File.Exists(fn))
                        {
                            proxy.PutFile(fn, File.ReadAllBytes(fn));
                        }
                        else Console.WriteLine("File not found");
                        break;
                    default:
                        timer.Abort();
                        foreach(var tick in ticks)
                        {
                            Console.WriteLine(tick);
                        }
                        Console.ReadKey(true);
                        return;
                }
            }
        }
    }
}
