﻿using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace ParserInterfaces
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IWCFParserService" in both code and config file together.
    [ServiceContract]
    public interface IWCFParserService
    {
        [OperationContract]
        long ParseText(string text);

        [OperationContract]
        long ParseStrings(List<string> strings);

        [OperationContract]
        void Echo(string name);

        [OperationContract]
        List<string> RetrieveList();

        [OperationContract]
        string Base64Encode(byte[] data);

        [OperationContract]
        byte[] Base64Decode(string base64EncodedData);

        [OperationContract]
        string Base64EncodeLocal(string filename, int start, int length);

        [OperationContract]
        void PutFile(string filename, byte[] data);

        [OperationContract]
        byte[] GetFile(string filename, int start, int length);

        [OperationContract]
        DateTime SendTime();

    }
}
