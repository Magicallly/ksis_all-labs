﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Threading.Tasks;

namespace TryTcpClient
{
    enum Action { Message, File, Speed, Packages, Exit }

    class Program
    {

        static string userName;
        private const string host = "127.0.0.1";
        private const int port = 8888;
        static Socket client;
        static string defaultPath = "D:\\prog\\4 sem\\KSIS\\";
        static byte[] check = new byte[256];

        static void Main(string[] args)
        {
            Console.Write("Enter name: ");
            userName = Console.ReadLine();
            client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint ipPoint = new IPEndPoint(IPAddress.Parse(host), port);

            try
            {
                client.Connect(ipPoint);

                string message = userName;
                byte[] data = Encoding.UTF8.GetBytes(message);
                client.Send(data);

                Thread receiveThread = new Thread(new ThreadStart(ReceiveMessage));
                receiveThread.Start();

                while (true)
                {
                    Console.WriteLine("Enter action number: 0 - send a message, 1 - send a file, " +
                            "2 - calculate speed, 3 - count lost packages, 4 - exit");
                    Action actionNum = (Action)Byte.Parse(Console.ReadLine());
                    ChooseAction(actionNum);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: {0}", ex.Message);
            }
            finally
            {
                Disconnect();
            }
        }


        private static void ChooseAction(Action action)
        {
            switch (action)
            {
                case Action.Message:
                    Console.WriteLine("Enter  message and press 'enter'");
                    SendMessage();
                    break;
                case Action.File:
                    Console.WriteLine("Enter full file path and press 'enter'");
                    SendFile();
                    break;
                case Action.Speed:
                    CalculateSpeed();
                    break;
                case Action.Packages:
                    CountPackages();
                    break;
                case Action.Exit:
                    Disconnect();
                    break;
                default:
                    Console.WriteLine("Wrong operation. Please try again");
                    break;
            }
        }

        

        static void SendMessage()
        {
            Console.WriteLine("Enter message: ");
            string message = '0' + userName + ':' + Console.ReadLine();
            byte[] data = Encoding.UTF8.GetBytes(message);
            client.Send(data);
        }

        private static void SendFile()
        {
            Console.WriteLine("Enter file path: ");
            string path = Console.ReadLine();
            FileInfo binFile = new FileInfo(path);
            string fileName = binFile.Name;
            int length = (int)binFile.Length;

            BinaryReader reader = new BinaryReader(File.Open(path, FileMode.Open));
            string message = '1' + userName + ":" + fileName + ";";
            byte[] prev = Encoding.UTF8.GetBytes(message);
            //EndPoint remotePoint = new IPEndPoint(IPAddress.Parse(host), port);
            client.Send(prev, prev.Length, 0);

            byte[] data = new byte[length];

            for (int i = 0; i < length; i++)
            {
                /*if (i < prev.Length)
                    data[i] = prev[i];
                else*/
                    data[i] = reader.ReadByte();
            }

            if (reader != null)
                reader.Close();

            client.Send(data, data.Length, 0);
        }

        private static void CalculateSpeed()
        {
            DateTime time = new DateTime();
            time = DateTime.Now;
            string message = '2' + time.ToString("mm:ss:ffffff");

            byte[] data = Encoding.UTF8.GetBytes(message);

            //EndPoint remotePoint = new IPEndPoint(IPAddress.Parse(host), port);
            client.Send(data, data.Length, 0);
        }

        private static void MakeSequence()
        {
            check[1] = 42;
            for (int i = 2; i < 256; i++)
            {
                check[i] = (byte)((check[i - 1] * 8 - 45 + 53 * (i + 7)) % 256);
            }
        }


        private static void CountPackages()
        {
            MakeSequence();
            check[0] = (byte)'3';
            byte[] data = check;

            //EndPoint remotePoint = new IPEndPoint(IPAddress.Parse(host), port);
            client.Send(data, data.Length, 0);
            Console.WriteLine("Send sequence of byte: {0}", check.ToString());
        }

        static void ReceiveMessage()
        {
            while (true)
            {
                try
                {
                    byte[] data = new byte[256];
                    int bytes = 0;

                    bytes = client.Receive(data, data.Length, 0);
                    Action action = (Action)(data[0] - 48);
                    DefineAction(action, ref data, bytes);

                }
                catch
                {
                    Console.WriteLine("Connection broken !");
                    Console.ReadLine();
                    Disconnect();
                }
            }
        }


        private static void DefineAction(Action action, ref byte[] data, int bytes)
        {
            switch (action)
            {
                case Action.Message:
                    ReceiveMessage(ref data, bytes);
                    break;
                case Action.File:
                    ReceiveFile(ref data, bytes);
                    break;
                case Action.Speed:
                    ReceiveSpeed(ref data, bytes);
                    break;
                case Action.Packages:
                    ReceivePackages(ref data, bytes);
                    break;
                case Action.Exit:
                    Disconnect();
                    break;
                default:
                    Console.WriteLine("Wrong operation. Please try again");
                    break;
            }
        }



        private static void ReceiveMessage(ref byte[] data, int bytes)
        {
            StringBuilder builder = new StringBuilder();
            EndPoint remoteIP = new IPEndPoint(IPAddress.Any, 0);
            builder.Append(Encoding.UTF8.GetString(data, 1, bytes - 1));

            while (client.Available > 0)
            {   //получение сообщений
                bytes = client.Receive(data, data.Length, 0);
                builder.Append(Encoding.UTF8.GetString(data, 0, bytes));
            }

            Console.WriteLine(builder.ToString());
        }

        private static void ReceiveFile(ref byte[] data, int bytes)
        {
            StringBuilder builder = new StringBuilder();
            //EndPoint remoteIP = new IPEndPoint(IPAddress.Any, 0);
            string message = Encoding.UTF8.GetString(data, 0, bytes);

            builder.Append(Encoding.UTF8.GetString(data, 1, message.IndexOf(';') - 1));
            string fileName = message.Substring(message.IndexOf(':') + 1, message.IndexOf(';') - message.IndexOf(':') - 1);

            string path = defaultPath + fileName;
            BinaryWriter writer = new BinaryWriter(File.Create(path));

            writer.Write(data, message.IndexOf(';') + 1, bytes - message.IndexOf(';') - 1);

            while (client.Available > 0)
            {   //получение сообщений
                bytes = client.Receive(data, data.Length, 0);
                writer.Write(data, 0, bytes);
            }

            if (writer != null)
            {
                writer.Flush();
                writer.Close();
            }

            Console.WriteLine(builder.ToString());
        }


        private static void ReceiveSpeed(ref byte[] data, int bytes)
        {
            int bytesNumber = bytes;
            StringBuilder builder = new StringBuilder();
            //EndPoint remoteIP = new IPEndPoint(IPAddress.Any, 0);
            builder.Append(Encoding.UTF8.GetString(data, 1, bytes - 1));

            while (client.Available > 0)
            {   //получение сообщений
                bytes = client.Receive(data, data.Length, 0);
                builder.Append(Encoding.UTF8.GetString(data, 0, bytes));
            }

            string message = builder.ToString();
            DateTime curTime = new DateTime();
            curTime = DateTime.Now;
            string time = curTime.ToString("mm:ss:ffffff");
            curTime = DateTime.ParseExact(time, "mm:ss:ffffff", System.Globalization.CultureInfo.InvariantCulture);
            DateTime recTime = DateTime.ParseExact(message, "mm:ss:ffffff", System.Globalization.CultureInfo.InvariantCulture);

            TimeSpan res = new TimeSpan();
            res = curTime.Subtract(recTime);

            Console.WriteLine("Speed: {0}b in {1}s", bytesNumber, res);
        }



        private static void ReceivePackages(ref byte[] data, int bytes)
        {
            StringBuilder builder = new StringBuilder();
            //EndPoint remoteIP = new IPEndPoint(IPAddress.Any, 0);
            builder.Append(Encoding.UTF8.GetString(data, 1, bytes - 1));

            MakeSequence();
            int index, failCount = 0;

            for (index = 1; index < bytes; index++)
            {
                if (check[index] != data[index])
                    failCount++;
            }

            while (client.Available > 0)
            {   //получение сообщений
                bytes = client.Receive(data, data.Length, 0);
                builder.Append(Encoding.UTF8.GetString(data, 0, bytes));
                int i = 0;
                while (index < check.Length)
                {
                    if (check[index] != data[i])
                        failCount++;
                    index++;
                    i++;
                }
            }

            Console.WriteLine("Receive sequency of byte: {0}", builder.ToString());
            Console.WriteLine("Number of lost packeges: {0}", failCount);
        }

        static void Disconnect()
        {
            if (client != null)
                client.Close();
            Environment.Exit(0);
        }
    }
}
