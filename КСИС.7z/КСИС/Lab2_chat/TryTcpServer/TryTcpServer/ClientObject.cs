﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace TryTcpServer
{
    enum Action { Message, File, Speed, Packages, Exit }

    class ClientObject
    {
        public string Id { get; private set; }
        protected static string userName;
        public Socket client;
        static ServerObject server;
        static string defaultPath = "D:\\prog\\4 sem\\KSIS\\";
        static byte[] check = new byte[256];


        public ClientObject(Socket tcpClient, ServerObject serverObject)
        {
            Id = Guid.NewGuid().ToString();
            client = tcpClient;
            server = serverObject;
            serverObject.AddConnection(this);
        }

        public void Process()
        {
            try
            {
                string message = GetMessage();
                userName = message;

                message = userName + " joined chat";
                //server.BroadcastMessage(message, ClientObject.Id);
                Console.WriteLine(message);

                while (true)
                {
                    try
                    {
                        int bytes = 0;
                        byte[] data = new byte[1024];
                        //EndPoint remoteIP = new IPEndPoint(IPAddress.Any, 0);

                        bytes = client.Receive(data);
                        Action action = (Action)(data[0] - 48);
                        DefineAction(action, ref data, bytes);

                        /*message = GetMessage();
                        message = String.Format("{0}: {1}", userName, message);
                        Console.WriteLine(message);
                        server.BroadcastMessage(message, this.Id);*/
                    }
                    catch
                    {
                        message = String.Format("{0}: left the chat", userName);
                        Console.WriteLine(message);
                        server.BroadcastMessage(message, this.Id);
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                server.RemoveConnection(this.Id);
                Close();
            }
        }


        private void DefineAction(Action action, ref byte[] data, int bytes)
        {
            switch (action)
            {
                case Action.Message:
                    ReceiveMessage(ref data, bytes);
                    break;
                case Action.File:
                    ReceiveFile(ref data, bytes);
                    break;
                case Action.Speed:
                    ReceiveSpeed(ref data, bytes);
                    break;
                case Action.Packages:
                    ReceivePackages(ref data, bytes);
                    break;
                case Action.Exit:
                    Close();
                    break;
                default:
                    Console.WriteLine("Wrong operation. Please try again");
                    break;
            }
        }

        private void ReceiveMessage(ref byte[] data, int bytes)
        {
            StringBuilder builder = new StringBuilder();
            //EndPoint remoteIP = new IPEndPoint(IPAddress.Any, 0);
            builder.Append(Encoding.UTF8.GetString(data, 1, bytes - 1));

            while (client.Available > 0)
            {   //получение сообщений
                bytes = client.Receive(data, data.Length, 0);
                builder.Append(Encoding.UTF8.GetString(data, 0, bytes));
            }

            Console.WriteLine(builder.ToString());
            server.BroadcastMessage('0' + builder.ToString(), this.Id);
        }

        private void ReceiveFile(ref byte[] data, int bytes)
        {
            StringBuilder builder = new StringBuilder();
            //EndPoint remoteIP = new IPEndPoint(IPAddress.Any, 0);
            string message = Encoding.UTF8.GetString(data, 0, bytes);

            builder.Append(Encoding.UTF8.GetString(data, 1, message.IndexOf(';') - 1));
            string fileName = message.Substring(message.IndexOf(':') + 1, message.IndexOf(';') - message.IndexOf(':') - 1);
        
            string path = defaultPath + fileName;
            BinaryWriter writer = new BinaryWriter(File.Create(path));

            writer.Write(data, message.IndexOf(';') + 1, bytes - message.IndexOf(';') - 1);

            while (client.Available > 0)
            {   //получение сообщений
                bytes = client.Receive(data, data.Length, 0);
                writer.Write(data, 0, bytes);
            }

            if (writer != null)
            {
                writer.Flush();
                writer.Close();
            }

            Console.WriteLine(builder.ToString());
            server.BroadcastMessage('0' + builder.ToString(), this.Id);
            SendFile(fileName);
            
        }

        private void SendFile(string fileName)
        {
            string path = defaultPath + fileName;
            FileInfo binFile = new FileInfo(path);
            int length = (int)binFile.Length;

            BinaryReader reader = new BinaryReader(File.Open(path, FileMode.Open));
            string message = '1' + userName + ":" + fileName + ";";
            byte[] prev = Encoding.UTF8.GetBytes(message);
            //EndPoint remotePoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8888);
            for (int i = 0; i < server.clients.Count; i++)
            {
                if (server.clients[i].Id != this.Id)
                {
                    server.clients[i].client.Send(prev, prev.Length, 0);
                }
            }
            

            byte[] data = new byte[length];

            for (int i = 0; i < length; i++)
            {
                /*if (i < prev.Length)
                    data[i] = prev[i];
                else*/
                    data[i] = reader.ReadByte();
            }

            if (reader != null)
                reader.Close();

            for (int i = 0; i < server.clients.Count; i++)
            {
                if (server.clients[i].Id != this.Id)
                {
                    server.clients[i].client.Send(data, data.Length, 0);
                }
            }
        }

        private void ReceiveSpeed(ref byte[] data, int bytes)
        {
            int bytesNumber = bytes + 1;
            StringBuilder builder = new StringBuilder();
            //EndPoint remoteIP = new IPEndPoint(IPAddress.Any, 0);
            builder.Append(Encoding.UTF8.GetString(data, 1, bytes - 1));

            while (client.Available > 0)
            {   //получение сообщений
                bytes = client.Receive(data, data.Length, 0);
                builder.Append(Encoding.UTF8.GetString(data, 0, bytes));
            }

            string message = builder.ToString();
            DateTime curTime = new DateTime();
            curTime = DateTime.Now;
            string time = curTime.ToString("mm:ss:ffffff");
            curTime = DateTime.ParseExact(time, "mm:ss:ffffff", System.Globalization.CultureInfo.InvariantCulture);
            DateTime recTime = DateTime.ParseExact(message, "mm:ss:ffffff", System.Globalization.CultureInfo.InvariantCulture);

            TimeSpan res = new TimeSpan();
            res = curTime.Subtract(recTime);

            Console.WriteLine("Speed: {0}b in {1}s", bytesNumber, res);
            server.BroadcastMessage('0' + $"Speed: {bytesNumber}b in {res}s", this.Id);
        }

        private static void MakeSequence()
        {
            check[1] = 42;
            for (int i = 2; i < 256; i++)
            {
                check[i] = (byte)((check[i - 1] * 8 - 45 + 53 * (i + 7)) % 256);
            }
        }

        private void ReceivePackages(ref byte[] data, int bytes)
        {
            StringBuilder builder = new StringBuilder();
            EndPoint remoteIP = new IPEndPoint(IPAddress.Any, 0);
            builder.Append(Encoding.UTF8.GetString(data, 1, bytes - 1));

            MakeSequence();
            int index, failCount = 0;

            for (index = 1; index < bytes; index++)
            {
                if (check[index] != data[index])
                    failCount++;
            }

            while (client.Available > 0)
            {   //получение сообщений
                bytes = client.Receive(data, data.Length, 0);
                builder.Append(Encoding.UTF8.GetString(data, 0, bytes));
                int i = 0;
                while (index < check.Length)
                {
                    if (check[index] != data[i])
                        failCount++;
                    index++;
                    i++;
                }
            }

            Console.WriteLine("Receive sequency of byte: {0}", builder.ToString());
            Console.WriteLine("Number of lost packeges: {0}", failCount);
            server.BroadcastMessage('0' + $"Receive sequency of byte: {builder.ToString()}\n" +
                $"Number of lost packeges: {failCount}", this.Id);
        }


        private string GetMessage()
        {
            byte[] data = new byte[1024];
            StringBuilder builder = new StringBuilder();
            int bytes = 0;
            
            do
            {
                bytes = client.Receive(data, data.Length, 0);
                builder.Append(Encoding.UTF8.GetString(data, 0, bytes));
            }
            while (client.Available > 0);

            return builder.ToString();
        }

        public void Close()
        {
            if (client != null)
                client.Close();
        }
    }
}
