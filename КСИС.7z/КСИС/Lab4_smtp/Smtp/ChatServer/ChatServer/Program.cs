﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Threading;
using System.Net;
using System.Text.RegularExpressions;
using System.Net.Mail;

namespace ChatServer
{
        public class ClientObject
        {
            public TcpClient client;
            public ClientObject(TcpClient tcpClient)
            {
                client = tcpClient;
            }

        public bool flag = false;
        public string from, to,pass,sub,text;

        public void mes(string from,string to,string sub,string text,string pass)
        {
                 MailAddress fr = new MailAddress(from, "USER");
                MailAddress t = new MailAddress(to);
                // создаем объект сообщения
                MailMessage m = new MailMessage(fr, t);
                m.Subject = sub;
                m.Body = string.Format("<h2>{0}</h2>",text);
                // письмо представляет код html
                m.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
                smtp.Credentials = new NetworkCredential(from, pass);
                smtp.EnableSsl = true;
                smtp.Send(m);
        }
    
        public string handler(string message)
        {
            if (message.StartsWith("FROM:"))
            {
                var rg = new Regex(@"<(.*)>");
                var result = rg.Match(message).Groups[1].Value;
                message = result;
                from = message;
                return "250 OK";
            }
            if (message.StartsWith("TO:"))
            {
                var rg = new Regex(@"<(.*)>");
                var result = rg.Match(message).Groups[1].Value;
                message = result;
                to = message;
                return "250 OK";
            }
            if (message.StartsWith("PASS:"))
            {
                var rg = new Regex(@"<(.*)>");
                var result = rg.Match(message).Groups[1].Value;
                message = result;
                pass = message;
                return "250 OK";
            }
            if (message.StartsWith("SUBJ:"))
            {
                var rg = new Regex(@"<(.*)>");
                var result = rg.Match(message).Groups[1].Value;
                message = result;
                sub = message;
                return "250 OK";
            }
            if (message == "DATA")
            {
                flag = true;
                return "Start input message";
            }
            if (message=="<CRLF>.<CRLF>")
            {
                flag = false;
                mes(from, to, sub, text, pass);
                return "250 OK";
            }
            if (message=="QUIT")
            {
                return "Server is closing transmission channel";
            }
            if (flag)
            {
                text = text + '\n' + message;
                return "er";
            }
            else
                return "ERROR";

        }

            public void Process()
            {
                NetworkStream stream = null;
                try
                {
                    stream = client.GetStream();
                    byte[] data = new byte[64]; // буфер для получаемых данных
                    while (true)
                    {
                        // получаем сообщение
                        StringBuilder builder = new StringBuilder();
                        int bytes = 0;
                        do
                        {
                            bytes = stream.Read(data, 0, data.Length);
                            builder.Append(Encoding.Unicode.GetString(data, 0, bytes));
                        }
                        while (stream.DataAvailable);

                        string message = builder.ToString();

                    message = handler(message);

                        Console.WriteLine(message);
                        data = Encoding.Unicode.GetBytes(message);
                        stream.Write(data, 0, data.Length);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    if (stream != null)
                        stream.Close();
                    if (client != null)
                        client.Close();
                }
            }
        }
    
    class Program
    {
        const int port = 8888;
        static TcpListener listener;
        static void Main(string[] args)
        {
            try
            {
                listener = new TcpListener(IPAddress.Parse("127.0.0.1"), port);
                listener.Start();
                Console.WriteLine("Ожидание подключений...");

                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();
                    ClientObject clientObject = new ClientObject(client);
                    
                    // новый поток для обслуживания нового клиента
                    Thread clientThread = new Thread(new ThreadStart(clientObject.Process));
                    clientThread.Start();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (listener != null)
                    listener.Stop();
            }
        }
    }
}