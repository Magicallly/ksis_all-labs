﻿using System;
using System.Text;
using System.Threading;
using System.Net.Sockets;

namespace ChatClient
{
    class Program
    {
        private static string host;
        private const int port = 8888;
        static TcpClient client;
        static NetworkStream stream;
        
        static void Main(string[] args)
        {
            Console.WriteLine("Enter host");
            client = new TcpClient();
            try
            {    
                host = Console.ReadLine();
                Console.WriteLine("MAIL From < Alex@mail.ru >");
                Console.WriteLine("250 Sender ok");
                Console.WriteLine("RCPT To:< ysemenov@mail.ch >");
                Console.WriteLine(" 250 < ysemenov@mail.ch > Recepient ok");
                Console.WriteLine(" DATA");

                client.Connect(host,port);
                stream = client.GetStream();

                Thread receivedThread = new Thread(new ThreadStart(ReceiveMessage));
                receivedThread.Start();
                SendMessage();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey(true);
            }
            finally
            {
                Disconnect();
            }
        }

        static void SendMessage()
        {
            while (true)
            {
                string message = Console.ReadLine();
                


 
                byte[] data = Encoding.Unicode.GetBytes(message);
                stream.Write(data, 0, data.Length);
            }
        }

        static void ReceiveMessage()
        {
            while (true)
            {
                try
                {
                    byte[] data = new byte[64];
                    StringBuilder builder = new StringBuilder();
                    int bytes = 0;
                    do
                    {
                        bytes = stream.Read(data, 0, data.Length);
                        builder.Append(Encoding.Unicode.GetString(data, 0, bytes));
                    }
                    while (stream.DataAvailable);

                    string message = builder.ToString();
                    if (message!="er")
                    Console.WriteLine(message);
                }
                catch
                {
                    Console.WriteLine("Server connection error");
                    Console.ReadLine();
                    Disconnect();
                }
            }
        }

        static void Disconnect()
        {
            if (stream != null)
                stream.Close();
            if (client != null)
                client.Close();
            Environment.Exit(0);
        }
    }
}
