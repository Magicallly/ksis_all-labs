﻿using System;
using System.IO;
using System.Linq;
using System.Text;

namespace WcfServiceLibrary
{
    public class Service : IService
    {
        private static int counter = 0;

        public string AppendFile(string fileName, Stream body)
        {
            StreamWriter writer = File.AppendText(fileName);
            writer.Write(new StreamReader(body).ReadToEnd());
            writer.Close();
            return "Ok";
        }

        public string Base64(Stream body)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(new StreamReader(body).ReadToEnd());
            return Convert.ToBase64String(bytes);
        }

        public string CreateFile()
        {
            string name = "File-" + counter++;
            File.Create(name).Close();
            return name;
        }

        public string FilePortion(string fileName, string offset, string size)
        {
            byte[] portion = File.ReadAllBytes(fileName).Skip(int.Parse(offset)).Take(int.Parse(size)).ToArray();
            return Encoding.Default.GetString(portion);
        }

        public int HashText(string text)
        {
            return text.GetHashCode();
        }
    }
}
