﻿using System.IO;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace WcfServiceLibrary
{
    [ServiceContract]
    public interface IService
    {
        [OperationContract]
        [WebInvoke(
            Method = "GET",
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "files/{fileName}?offset={offset}&size={size}"
        )]
        string FilePortion(string fileName, string offset, string size);

        [OperationContract]
        [WebInvoke(
            Method = "POST",
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "files"
        )]
        string CreateFile();

        [OperationContract]
        [WebInvoke(
            Method = "POST",
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "files/{fileName}/portions"
        )]
        string AppendFile(string fileName, Stream body);

        [OperationContract]
        [WebInvoke(
            Method = "GET",
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "actions/hash?text={text}"
        )]
        int HashText(string text);

        [OperationContract]
        [WebInvoke(
            Method = "POST",
            ResponseFormat = WebMessageFormat.Json,
            UriTemplate = "actions/base64"
        )]
        string Base64(Stream body);
    }
}
