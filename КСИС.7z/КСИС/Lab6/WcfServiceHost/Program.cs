﻿using System;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.ServiceModel;
using WcfServiceLibrary;

namespace WcfServiceHost
{
    class Program
    {
        static void Main(string[] args)
        {
            var host = new WebServiceHost(typeof(Service), new Uri("http://localhost:8000/"));
            var ep = host.AddServiceEndpoint(typeof(IService), new WebHttpBinding(), "");
            var sdb = host.Description.Behaviors.Find<ServiceDebugBehavior>();
            sdb.HttpHelpPageEnabled = false;

            host.Open();
            Console.WriteLine("Press <Enter> to quit...");
            Console.ReadLine();
            host.Close();
        }
    }
}
