﻿using System;
using System.Net.Http;

namespace WcfServiceClient
{
    class Program
    {
        static HttpClient client = new HttpClient();
        static void Main(string[] args)
        {
            client.BaseAddress = new Uri("http://localhost:8000");
            client.DefaultRequestHeaders.Accept.Clear();
            CreateFile();
            Append();
            Portion();
            Hash();
            Base64();
            Console.ReadLine();
        }

        private static void CreateFile()
        {
            HttpResponseMessage response = client.PostAsync("/files", new StringContent("")).Result;
            Console.WriteLine(response.Content.ReadAsStringAsync().Result);
        }

        private static void Portion()
        {
            HttpResponseMessage response = client.GetAsync("/files/File-0?offset=2&size=3").Result;
            Console.WriteLine(response.Content.ReadAsStringAsync().Result);
        }

        private static void Append()
        {
            HttpResponseMessage response = client.PostAsync("/files/File-0/portions", new StringContent("Hello,world!")).Result;
            Console.WriteLine(response.Content.ReadAsStringAsync().Result);
        }

        private static void Hash()
        {
            HttpResponseMessage response = client.GetAsync("/actions/hash?text=Hello,world!").Result;
            Console.WriteLine(response.Content.ReadAsStringAsync().Result);
        }

        private static void Base64()
        {
            HttpResponseMessage response = client.PostAsync("/actions/base64", new StringContent("Hello,world!")).Result;
            Console.WriteLine(response.Content.ReadAsStringAsync().Result);
        }
    }
}
